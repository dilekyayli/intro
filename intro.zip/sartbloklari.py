dolarDun = 7.65
dolarBugun = 7.65

if dolarDun > dolarBugun:
 print("Azalış oku")
 print("Bitti")
elif dolarDun < dolarBugun:
  print("Artış oku")
else:
  print("Eşittir oku")
  
print("Bitti")


#if dolarDun < dolarBugun:
  #print("Artış oku")

#if dolarDun == dolarBugun:
  #print("Eşittir oku")