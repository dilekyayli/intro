#en büyük değer
sayi1 = 25
sayi2 = 35
sayi3 = 45 
if sayi1 > sayi2 and sayi1 > sayi3:
	print("en büyük değer sayi1'dir")
elif sayi2 > sayi1 and sayi2 > sayi3:
	print("en büyük değer sayi2'dir")
else:
	print("en büyük değer sayi3'tür")

#en küçük değer
if sayi1 < sayi2 and sayi1 < sayi3:
	print("en küçük değer sayi1'dir")
elif sayi2 < sayi1 and sayi2 < sayi3:
	print("en küçük değer sayi2'dir")
else:
	print("en küçük değer sayi3'tür")