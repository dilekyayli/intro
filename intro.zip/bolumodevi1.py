sayi1 = 36
sayi2 = 46


if sayi1 > sayi2:
 print("büyüktür")
 print("Bitti")
elif sayi1 < sayi2:
  print("küçüktür")