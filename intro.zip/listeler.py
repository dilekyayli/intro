krediler = ["Hızlı Kredi", "Maaşını Halkbank'tan alanlara özel", "Mutlu emekli ihtiyaç kredisi"]

print(krediler)
print(krediler[0]) #listenin 1.elemanı
print(krediler[1]) #listenin 2.elemanı
print(krediler[2]) #listenin 3.elemanı

print(len(krediler)) #listedeki eleman sayısı #length : 

krediler[0] = "Çabuk kredi"
print(krediler) #ilk elemanı değiştirme

print(krediler[5])