baslik = 'HABERİNİZ OLSUN'  #string
vade = 12 #integer
faizOrani1 = 1.47 #float
faizOrani2 = 1.44
faizOrani = 1.47

print(baslik)
print(type(baslik))
print(type(vade))
print(type(faizOrani1))

mesaj = "Hoşgeldin"
musteriAdi = "Engin"
musteriSoyadi = "Demiroğ"
sonucMesaj = mesaj+" "+musteriAdi+" "+musteriSoyadi+"!"

print(sonucMesaj)

sayi1 = 10
sayi2 = 20
print(sayi1+sayi2)

print(sonucMesaj)