ogrenciler = ["Ayşe", "Fatma", "Hatice", "Ali", "Veli"]

print(ogrenciler)
['Ayşe', 'Fatma', 'Hatice', 'Ali', 'Veli']
print(ogrenciler[0])
print(ogrenciler[1])
print(ogrenciler[2])
print(ogrenciler[3])
print(ogrenciler[4])
print(ogrenciler[5])

print(len(ogrenciler)) 
ogrenciler[0] ="Mehmet"
print(ogrenciler)
