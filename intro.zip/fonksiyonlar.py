print("İlk sayfa")
krediler = [ "Hızlı kredi","Maaşını Halkbank'tan alanlara özel", "Mutlu emekli ihtiyaç kredisi"]


def kredileriListele(): #tanımlamak
  krediler = ["Maaşını Halkbank'tan alanlara özel", "Mutlu emekli ihtiyaç kredisi"]
  for kredi in krediler:  
   print("<option>"+kredi+"<option>")

kredileriListele() #fonksiyonu çağırmak
kredileriListele()
kredileriListele()
kredileriListele()
kredileriListele()
kredileriListele()
kredileriListele()