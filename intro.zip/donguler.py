krediler = ["Hızlı Kredi", "Maaşını Halkbank'tan alanlara özel", "Mutlu emekli ihtiyaç kredisi"]


for kredi in krediler:
  print(kredi)



for i in range(len(krediler)):
  print(krediler[i])

for i in range(3,10): #3 dahil 10 dahil değil
  print(i)

for i in range(0,11,2): #0'dan başla 2'şer 2'şer arttır 
  print(i)